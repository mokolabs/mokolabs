module ActiveRecord
  module ActsNaked
    def self.append_features(base)
      base.extend(ClassMethods)
    end
    
    module ClassMethods
      def acts_naked(options = {})

        all_strings_and_text = self.columns.select { |c| c.type == :string or c.type == :text }
        
        columns_to_strip = Array.new
        if options[:only]
          options[:only] = [options[:only]] unless options[:only].is_a?(Array)
          options[:only].each do | inc_col |
            col = all_strings_and_text.detect { |c| c.name == inc_col.to_s }
            columns_to_strip << col if col
          end
        else
          columns_to_strip = all_strings_and_text
        end
        
        if options[:except]
          options[:except] = [options[:except]] unless options[:except].is_a?(Array)
          options[:except].each do | exc_col |
            columns_to_strip.delete_if { |c| c.name == exc_col.to_s }
          end
        end
        
        columns_to_strip = columns_to_strip.collect { |c| c.name }.join("|")
        
        class_eval <<-EOV
          include ActiveRecord::ActsNaked::InstanceMethods
          
          def columns_to_be_stripped
            \"#{columns_to_strip}\"
          end

          options[:with] = :before_save unless options[:with]
          ActiveRecord::Base.send(options[:with], :strip_text)

        EOV
      end
    end
      
    module InstanceMethods
      private
      
      def strip_text
        columns_to_strip = columns_to_be_stripped
        columns_to_strip.split("|").each { |name| self[name].strip! if self[name] } if columns_to_strip
      end
    end
  end
end

ActiveRecord::Base.class_eval do 
  include ActiveRecord::ActsNaked
end