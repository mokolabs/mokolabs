require 'acts_naked.rb'
